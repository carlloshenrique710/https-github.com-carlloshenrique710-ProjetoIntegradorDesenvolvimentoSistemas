<?php
$con = mysqli_connect("localhost","root","","paws") or die ('Sem conexão');

?>