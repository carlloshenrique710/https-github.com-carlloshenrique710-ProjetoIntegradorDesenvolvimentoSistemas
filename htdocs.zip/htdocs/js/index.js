/* Get elements
const username = document.getElementById('email');
const password = document.getElementById('password');
const acessar = document.getElementById('acessar');

// Add login event
	//acessar.addEventListener("click", function() {
//	$("logar").click(
	function logar(onclick){
	// Get email and password
	const user = email.value;
	const pass = password.value;
	const auth = firebase.auth();
	// Sign in
	const promise = auth.singInWithEmailAndPassword(email, password);
      window.location = 'HomePage.html';
    };             
*/
$("#formLogin").submit(function (e){
        e.preventDefault();
 
         $.ajax({
            type: "POST",
            url: "xampp/htdocs/login2.php", 
            data: {
                acao: 'login2',
                usuario: $("#usuario").val(),
                senha: $("#senha").val()
            },            
            async: false,
            dataType: "json", 
            success: function (json) {
 
                if(json.result == true){
                   //redireciona o usuario para pagina
                   $("#usuario_nome").html(json.dados.nome);
 
                   $.mobile.changePage("#index", {
                        transition : "slidefade"
                    });
 
                }else{
                   alert(json.msg);
                }
            },error: function(xhr,e,t){
                console.log(xhr.responseText);                
            }
        });
      });	
