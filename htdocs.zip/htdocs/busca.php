<?php
include("conexao.php");

$sql = mysql_query("SELECT * FROM `paws`.`pet`");



?>